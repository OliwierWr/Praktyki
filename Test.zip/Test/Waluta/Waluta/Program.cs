﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine(waluta());
    }

    public static double waluta()
    {
        Console.WriteLine("Podaj ilość zł");
        string PLN = Console.ReadLine();
        double PLN_float= float.Parse(PLN);
        double USD = PLN_float / 3.95;
        Console.WriteLine(PLN + " to " + Math.Round(USD,2));
        return 0;
    }
}